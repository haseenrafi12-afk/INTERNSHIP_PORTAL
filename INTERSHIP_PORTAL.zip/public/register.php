<?php
require_once __DIR__ . "/config/database.php";
if (session_status() === PHP_SESSION_NONE) session_start();
if (!empty($_SESSION['user_id'])) { header("Location: " . ($_SESSION['role']==='student' ? "student/dashboard.php" : "company/dashboard.php")); exit; }
$error = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'student';
    $company = trim($_POST['company_name'] ?? '');
    if (!$name || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<6) {
        $error = "Enter a valid name, email and password (6+ characters).";
    } elseif (!in_array($role,['student','company'],true)) {
        $error = "Invalid account type.";
    } else {
        try {
            $pdo->beginTransaction();
            $s=$pdo->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)");
            $s->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),$role]);
            $uid=(int)$pdo->lastInsertId();
            if ($role==='student') {
                $s=$pdo->prepare("INSERT INTO students(user_id,skills) VALUES(?,?)"); $s->execute([$uid,'']);
            } else {
                $company = $company ?: $name;
                $s=$pdo->prepare("INSERT INTO companies(user_id,company_name) VALUES(?,?)"); $s->execute([$uid,$company]);
            }
            $pdo->commit();
            header("Location: login.php?registered=1"); exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = "Email may already be registered.";
        }
    }
}
$title="Create account"; $cssPath="css/style.css"; $jsPath="js/app.js"; $homePath="index.php"; $rootPath="";
require "includes/header.php";
?>
<div class="auth-wrap"><div class="auth-card">
  <span class="eyebrow">JOIN THE COMMUNITY</span><h1>Create your account</h1><p class="muted">Create your profile and discover opportunities that match your ambition.</p>
  <?php if($error): ?><div class="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="post" data-validate>
    <label>Full name<input name="name" required></label>
    <label>Email<input type="email" name="email" required></label>
    <label>Account type<select name="role" id="role" onchange="toggleCompany()"><option value="student">Student</option><option value="company">Company</option></select></label>
    <label id="companyField" class="hidden">Company name<input name="company_name"></label>
    <label>Password<input type="password" name="password" minlength="6" required></label>
    <button class="btn primary full">Create account</button>
  </form>
  <p class="center muted">Already registered? <a href="login.php">Login</a></p>
</div></div>
<?php require "includes/footer.php"; ?>
