<?php
require_once "../config/database.php"; require_once "../includes/auth.php"; require_role("student");
$uid=$_SESSION['user_id']; $s=$pdo->prepare("SELECT * FROM students WHERE user_id=?"); $s->execute([$uid]); $st=$s->fetch();
$msg="";
if($_SERVER['REQUEST_METHOD']==='POST'){
 $bio=trim($_POST['bio']??''); $skills=trim($_POST['skills']??''); $phone=trim($_POST['phone']??'');
 $s=$pdo->prepare("UPDATE students SET bio=?,skills=?,phone=? WHERE user_id=?"); $s->execute([$bio,$skills,$phone,$uid]); $msg="Profile updated successfully.";
 $st=array_merge($st,['bio'=>$bio,'skills'=>$skills,'phone'=>$phone]);
}
$title="My Profile"; $cssPath="../css/style.css"; $jsPath="../js/app.js"; $homePath="../index.php"; $rootPath="../";
require "../includes/header.php";
?>
<div class="narrow"><span class="eyebrow">PROFILE</span><h1>Build your student profile</h1><p class="muted">Give companies a quick picture of what you can do.</p>
<?php if($msg): ?><div class="success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<form class="form-card" method="post">
<label>Phone<input name="phone" value="<?= htmlspecialchars($st['phone']??'') ?>"></label>
<label>Skills <small>Comma separated</small><input name="skills" placeholder="PHP, MySQL, JavaScript" value="<?= htmlspecialchars($st['skills']??'') ?>"></label>
<label>About you<textarea name="bio" rows="6" placeholder="Tell companies about your interests..."><?= htmlspecialchars($st['bio']??'') ?></textarea></label>
<button class="btn primary">Save profile</button>
</form></div>
<?php require "../includes/footer.php"; ?>
