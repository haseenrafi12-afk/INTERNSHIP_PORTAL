<?php
require_once "../config/database.php"; require_once "../includes/auth.php"; require_role("student");
$q=trim($_GET['q']??''); $mode=trim($_GET['mode']??'');
$sql="SELECT i.*,c.company_name FROM internships i JOIN companies c ON c.id=i.company_id WHERE i.deadline>=CURDATE()";
$params=[];
if($q){$sql.=" AND (i.title LIKE ? OR i.skills LIKE ? OR c.company_name LIKE ?)"; $like="%$q%"; $params=[$like,$like,$like];}
if($mode){$sql.=" AND i.work_mode=?"; $params[]=$mode;}
$sql.=" ORDER BY i.created_at DESC";
$s=$pdo->prepare($sql); $s->execute($params); $rows=$s->fetchAll();
$title="Internships"; $cssPath="../css/style.css"; $jsPath="../js/app.js"; $homePath="../index.php"; $rootPath="../";
require "../includes/header.php";
?>
<div class="section-head"><div><span class="eyebrow">OPPORTUNITIES</span><h1>Find your next internship</h1></div></div>
<form class="filterbar"><input name="q" value="<?= htmlspecialchars($q) ?>" placeholder="Search role, company or skill..."><select name="mode"><option value="">All work modes</option><option <?= $mode==='Remote'?'selected':'' ?>>Remote</option><option <?= $mode==='Hybrid'?'selected':'' ?>>Hybrid</option><option <?= $mode==='On-site'?'selected':'' ?>>On-site</option></select><button class="btn primary">Search</button></form>
<div class="card-grid"><?php foreach($rows as $i): ?><article class="intern-card"><div class="card-top"><span class="company-dot"><?= strtoupper(substr($i['company_name'],0,1)) ?></span><span class="pill"><?= htmlspecialchars($i['work_mode']) ?></span></div><h3><?= htmlspecialchars($i['title']) ?></h3><p class="muted"><?= htmlspecialchars($i['company_name']) ?></p><p><?= htmlspecialchars($i['description']) ?></p><div class="tags"><span><?= htmlspecialchars($i['location']) ?></span><span><?= htmlspecialchars($i['duration']) ?></span></div><div class="card-bottom"><small>Until <?= htmlspecialchars($i['deadline']) ?></small><a href="details.php?id=<?= (int)$i['id'] ?>">View role →</a></div></article><?php endforeach; ?></div>
<?php require "../includes/footer.php"; ?>
