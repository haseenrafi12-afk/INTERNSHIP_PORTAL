<?php
require_once "../config/database.php"; require_once "../includes/auth.php"; require_role("student");
if($_SERVER['REQUEST_METHOD']!=='POST'){header("Location: internships.php");exit;}
$iid=(int)($_POST['internship_id']??0); $uid=$_SESSION['user_id'];
$s=$pdo->prepare("SELECT id FROM students WHERE user_id=?");$s->execute([$uid]);$sid=$s->fetchColumn();
try{
 $s=$pdo->prepare("INSERT INTO applications(student_id,internship_id,status) VALUES(?,?, 'Applied')");$s->execute([$sid,$iid]);
}catch(Throwable $e){}
header("Location: applications.php");exit;
