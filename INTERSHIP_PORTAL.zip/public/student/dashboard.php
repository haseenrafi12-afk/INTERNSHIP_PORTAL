<?php

require_once "../config/database.php";
require_once "../includes/auth.php";

require_role("student");

$uid = $_SESSION['user_id'];

$s = $pdo->prepare("SELECT * FROM students WHERE user_id = ?");
$s->execute([$uid]);
$student = $s->fetch();

$s = $pdo->prepare("SELECT COUNT(*) FROM applications WHERE student_id = ?");
$s->execute([$student['id']]);
$applications = $s->fetchColumn();

$s = $pdo->query("SELECT COUNT(*) FROM internships WHERE deadline >= CURDATE()");
$open = $s->fetchColumn();

/* Count skills */
$skillsCount = 0;

if (!empty($student['skills'])) {
    $skillsArray = explode(",", $student['skills']);

    foreach ($skillsArray as $skill) {
        if (trim($skill) !== "") {
            $skillsCount++;
        }
    }
}

$title = "Student Dashboard";
$cssPath = "../css/style.css";
$jsPath = "../js/app.js";
$homePath = "../index.php";
$rootPath = "../";

require "../includes/header.php";

?>

<div class="dash-head">
    <div>
        <span class="eyebrow">STUDENT SPACE</span>

        <h1>
            Hey, <?= htmlspecialchars($_SESSION['name']) ?> 👋
        </h1>

        <p class="muted">
            Your next opportunity starts here.
        </p>
    </div>

    <a class="btn primary" href="internships.php">
        Find internships
    </a>
</div>

<div class="stats">

    <div>
        <b><?= $applications ?></b>
        <span>Applications</span>
    </div>

    <div>
        <b><?= $open ?></b>
        <span>Open roles</span>
    </div>

    <div>
        <b><?= $skillsCount ?></b>
        <span>Skills added</span>
    </div>

</div>

<div class="quick-grid">

    <a href="profile.php" class="quick">
        <span>01</span>
        <h3>Complete profile</h3>
        <p>Add your skills and bio.</p>
        →
    </a>

    <a href="internships.php" class="quick">
        <span>02</span>
        <h3>Explore roles</h3>
        <p>Search internships that fit you.</p>
        →
    </a>

    <a href="applications.php" class="quick">
        <span>03</span>
        <h3>Track progress</h3>
        <p>See every application status.</p>
        →
    </a>

</div>

<?php require "../includes/footer.php"; ?>