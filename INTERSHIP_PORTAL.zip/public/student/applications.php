<?php
require_once "../config/database.php"; require_once "../includes/auth.php"; require_role("student");
$s=$pdo->prepare("SELECT a.*,i.title,c.company_name FROM applications a JOIN students st ON st.id=a.student_id JOIN internships i ON i.id=a.internship_id JOIN companies c ON c.id=i.company_id WHERE st.user_id=? ORDER BY a.applied_at DESC");$s->execute([$_SESSION['user_id']]);$rows=$s->fetchAll();
$title="Applications";$cssPath="../css/style.css";$jsPath="../js/app.js";$homePath="../index.php";$rootPath="../";require "../includes/header.php";
?>
<span class="eyebrow">TRACKING</span><h1>My applications</h1><div class="table-card"><table><thead><tr><th>Role</th><th>Company</th><th>Applied</th><th>Status</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= htmlspecialchars($r['title']) ?></td><td><?= htmlspecialchars($r['company_name']) ?></td><td><?= htmlspecialchars(substr($r['applied_at'],0,10)) ?></td><td><span class="status"><?= htmlspecialchars($r['status']) ?></span></td></tr><?php endforeach; ?></tbody></table></div>
<?php require "../includes/footer.php"; ?>
