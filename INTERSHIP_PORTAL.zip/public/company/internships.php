<?php
require_once "../config/database.php";require_once "../includes/auth.php";require_role("company");
$s=$pdo->prepare("SELECT * FROM companies WHERE user_id=?");$s->execute([$_SESSION['user_id']]);$cid=$s->fetchColumn();$s=$pdo->prepare("SELECT * FROM internships WHERE company_id=? ORDER BY created_at DESC");$s->execute([$cid]);$rows=$s->fetchAll();
$title="My Internships";$cssPath="../css/style.css";$jsPath="../js/app.js";$homePath="../index.php";$rootPath="../";require "../includes/header.php";
?>
<div class="section-head"><div><span class="eyebrow">YOUR LISTINGS</span><h1>Internship posts</h1></div><a class="btn primary" href="add_internship.php">+ Add new</a></div>
<div class="table-card"><table><thead><tr><th>Role</th><th>Mode</th><th>Deadline</th><th>Action</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= htmlspecialchars($r['title']) ?></td><td><?= htmlspecialchars($r['work_mode']) ?></td><td><?= htmlspecialchars($r['deadline']) ?></td><td><a href="applicants.php?internship=<?= (int)$r['id'] ?>">Applicants →</a></td></tr><?php endforeach; ?></tbody></table></div>
<?php require "../includes/footer.php"; ?>
