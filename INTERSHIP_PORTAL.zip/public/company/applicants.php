<?php
require_once "../config/database.php";require_once "../includes/auth.php";require_role("company");
$s=$pdo->prepare("SELECT id FROM companies WHERE user_id=?");$s->execute([$_SESSION['user_id']]);$cid=$s->fetchColumn();
if($_SERVER['REQUEST_METHOD']==='POST'){ $aid=(int)$_POST['application_id'];$status=$_POST['status'];$s=$pdo->prepare("UPDATE applications a JOIN internships i ON i.id=a.internship_id SET a.status=? WHERE a.id=? AND i.company_id=?");$s->execute([$status,$aid,$cid]);}
$sql="SELECT a.*,u.name,u.email,i.title FROM applications a JOIN students st ON st.id=a.student_id JOIN users u ON u.id=st.user_id JOIN internships i ON i.id=a.internship_id WHERE i.company_id=?";$params=[$cid];
if(!empty($_GET['internship'])){$sql.=" AND i.id=?";$params[]=(int)$_GET['internship'];}$sql.=" ORDER BY a.applied_at DESC";
$s=$pdo->prepare($sql);$s->execute($params);$rows=$s->fetchAll();
$title="Applicants";$cssPath="../css/style.css";$jsPath="../js/app.js";$homePath="../index.php";$rootPath="../";require "../includes/header.php";
?>
<span class="eyebrow">TALENT PIPELINE</span><h1>Applicants</h1><div class="table-card"><table><thead><tr><th>Candidate</th><th>Role</th><th>Email</th><th>Status</th><th>Update</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= htmlspecialchars($r['name']) ?></td><td><?= htmlspecialchars($r['title']) ?></td><td><?= htmlspecialchars($r['email']) ?></td><td><span class="status"><?= htmlspecialchars($r['status']) ?></span></td><td><form class="inline-form" method="post"><input type="hidden" name="application_id" value="<?= (int)$r['id'] ?>"><select name="status"><option>Applied</option><option>Under Review</option><option>Shortlisted</option><option>Interview</option><option>Selected</option><option>Rejected</option></select><button>Save</button></form></td></tr><?php endforeach; ?></tbody></table></div>
<?php require "../includes/footer.php"; ?>
