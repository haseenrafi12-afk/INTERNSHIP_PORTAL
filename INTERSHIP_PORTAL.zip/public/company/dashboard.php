<?php
require_once "../config/database.php";require_once "../includes/auth.php";require_role("company");
$s=$pdo->prepare("SELECT id,company_name FROM companies WHERE user_id=?");$s->execute([$_SESSION['user_id']]);$co=$s->fetch();
$s=$pdo->prepare("SELECT COUNT(*) FROM internships WHERE company_id=?");$s->execute([$co['id']]);$roles=$s->fetchColumn();
$s=$pdo->prepare("SELECT COUNT(*) FROM applications a JOIN internships i ON i.id=a.internship_id WHERE i.company_id=?");$s->execute([$co['id']]);$apps=$s->fetchColumn();
$title="Company Dashboard";$cssPath="../css/style.css";$jsPath="../js/app.js";$homePath="../index.php";$rootPath="../";require "../includes/header.php";
?>
<div class="dash-head"><div><span class="eyebrow">COMPANY SPACE</span><h1><?= htmlspecialchars($co['company_name']) ?></h1><p class="muted">Manage opportunities and discover talent.</p></div><a class="btn primary" href="add_internship.php">+ Post internship</a></div>
<div class="stats"><div><b><?= $roles ?></b><span>Internship posts</span></div><div><b><?= $apps ?></b><span>Total applicants</span></div><div><b>24/7</b><span>Talent access</span></div></div>
<div class="quick-grid"><a class="quick" href="add_internship.php"><span>01</span><h3>Create a role</h3><p>Publish a new internship opening.</p>→</a><a class="quick" href="internships.php"><span>02</span><h3>Manage roles</h3><p>Edit and review your listings.</p>→</a><a class="quick" href="applicants.php"><span>03</span><h3>Review talent</h3><p>Track and update applicants.</p>→</a></div>
<?php require "../includes/footer.php"; ?>
