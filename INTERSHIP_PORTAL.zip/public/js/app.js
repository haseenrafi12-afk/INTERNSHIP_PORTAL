function toggleCompany(){
 const role=document.getElementById("role"), box=document.getElementById("companyField");
 if(role&&box) box.classList.toggle("hidden",role.value!=="company");
}
document.addEventListener("DOMContentLoaded",()=>{
 document.querySelectorAll("form[data-validate]").forEach(form=>{
   form.addEventListener("submit",e=>{
     const p=form.querySelector('input[name="password"]');
     if(p&&p.value.length<6){e.preventDefault();alert("Password must contain at least 6 characters.");}
   });
 });
});
