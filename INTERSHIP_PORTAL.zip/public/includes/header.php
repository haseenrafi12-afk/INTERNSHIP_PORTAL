<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$title = $title ?? "InternUp";
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($title) ?> | InternUp</title>
<link rel="stylesheet" href="<?= $cssPath ?? 'css/style.css' ?>">
</head>
<body>
<header class="topbar">
  <a class="brand" href="<?= $homePath ?? 'index.php' ?>"><span>IU</span> InternUp</a>
  <nav>
    <?php if (!empty($_SESSION['user_id'])): ?>
      <?php if ($_SESSION['role'] === 'student'): ?>
        <a href="<?= $rootPath ?? '' ?>student/dashboard.php">Dashboard</a>
        <a href="<?= $rootPath ?? '' ?>student/internships.php">Internships</a>
        <a href="<?= $rootPath ?? '' ?>student/applications.php">Applications</a>
      <?php else: ?>
        <a href="<?= $rootPath ?? '' ?>company/dashboard.php">Dashboard</a>
        <a href="<?= $rootPath ?? '' ?>company/internships.php">Internships</a>
      <?php endif; ?>
      <a class="nav-cta" href="<?= $rootPath ?? '' ?>logout.php">Logout</a>
    <?php else: ?>
      <a href="<?= $homePath ?? 'index.php' ?>">Home</a>
      <a href="<?= $rootPath ?? '' ?>login.php">Login</a>
      <a class="nav-cta" href="<?= $rootPath ?? '' ?>register.php">Get Started</a>
    <?php endif; ?>
  </nav>
</header>
<main class="page">
