</main>
<footer class="footer">© <?= date('Y') ?> InternUp · Bridging Students with Opportunities</footer>
<script src="<?= $jsPath ?? 'js/app.js' ?>"></script>
</body>
</html>
