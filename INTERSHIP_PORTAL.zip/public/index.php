<?php
require_once __DIR__ . "/config/database.php";
$title = "Build your next opportunity";
$cssPath = "css/style.css"; $jsPath = "js/app.js"; $homePath = "index.php"; $rootPath = "";
$stmt = $pdo->query("SELECT i.*, c.company_name FROM internships i JOIN companies c ON c.id=i.company_id WHERE i.deadline >= CURDATE() ORDER BY i.created_at DESC LIMIT 6");
$internships = $stmt->fetchAll();
require "includes/header.php";
?>
<section class="hero">
  <div class="hero-copy">
    <div class="eyebrow">YOUR FUTURE, UNLOCKED</div>
    <h1>Make your next move <em>count with InternUp.</em></h1>
    <p>Discover hands-on internships, build real-world skills, and take your first step toward a career you love.</p>
    <div class="hero-actions">
      <a class="btn primary" href="register.php">Explore internships →</a>
      <a class="btn ghost" href="login.php">I already have an account</a>
    </div>
  </div>
  <div class="hero-panel">
    <div class="panel-label">YOUR NEXT CHAPTER STARTS HERE</div>
    <div class="metric"><strong><?= count($internships) ?>+</strong><span>open roles</span></div>
    <div class="mini-line"><span>Built for students</span><b>●</b></div>
    <div class="mini-line"><span>Career-focused roles</span><b>●</b></div>
  </div>
</section>

<section class="section">
  <div class="section-head"><div><span class="eyebrow">FIND YOUR FIT</span><h2>Explore opportunities. Build skills. Move forward.</h2></div><a href="login.php" class="text-link">See opportunities →</a></div>
  <div class="card-grid">
    <?php foreach ($internships as $i): ?>
      <article class="intern-card">
        <div class="card-top"><span class="company-dot"><?= strtoupper(substr($i['company_name'],0,1)) ?></span><span class="pill"><?= htmlspecialchars($i['work_mode']) ?></span></div>
        <h3><?= htmlspecialchars($i['title']) ?></h3>
        <p class="muted"><?= htmlspecialchars($i['company_name']) ?></p>
        <div class="tags"><span><?= htmlspecialchars($i['location']) ?></span><span><?= htmlspecialchars($i['duration']) ?></span></div>
        <div class="card-bottom"><small>Deadline <?= htmlspecialchars($i['deadline']) ?></small><a href="login.php">Explore</a></div>
      </article>
    <?php endforeach; ?>
  </div>
</section>
<?php require "includes/footer.php"; ?>
